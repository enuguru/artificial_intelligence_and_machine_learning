# Simple Sentiment Analysis Code Using NLTK
This is a simple code to test NLTK naive bayes classifier and use it in Sentiment Analysis

## Dependencies
NLTK is the only dependency

## Usage
Run ```python main.py``` to see the resulting GUI.