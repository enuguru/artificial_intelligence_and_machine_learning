# Clustering using Python

In this repository you can find mini-projects that explains clustering Machine Learning tecnihuqes. All projects are done in Python programming languange.


## More information

Each mini project has its own README file where you can find more information about project itself.

### Custom algorithms

Please find folder called **algorithms_custom** where you can inspect KMeans, Means Shift.. algorithms wrote from scratch using only numpy. This can help you to understand intuition behind blackbox version of algorithm in Scikit-learn library. 

## Lincese

Each project has MIT Lincese.
