from numpy import array
from numpy import mean
from numpy import cov
from numpy.linalg import eig


# define a matrix
print()
A = array([[1, 2], [3, 4], [5, 6]])
print("define a matrix")
print(A)
print()


# calculate the mean of each column
M = mean(A.T, axis=1)
print("mean of the matrix")
print(M)
print()


# center columns by subtracting column means
C = A - M
print("center columns by subtracting column means")
print(C)
print()


# calculate covariance matrix of centered matrix
V = cov(C.T)
print("calculate covariance matrix of centered matrix")
print(V)
print()


# eigendecomposition of covariance matrix
values, vectors = eig(V)
print("eigen vectors")
print(vectors)
print()


# eigendecomposition of covariance matrix
print("eigen values")
print(values)
print()


# project data
P = vectors.T.dot(C.T)
print("project the data")
print(P.T)
print()



