
import numpy as np
from numpy import linalg as LA
A = np.array([[1,2,3],[3,2,1],[1,0,-1]])
w, v = LA.eig(A)
print(w)
print(v)


u = v[:,1]
print(u)
lam = w[1]
print(lam)
#print(np.dot(A,u))
#print(lam*u)


w, v = LA.eig(A)
idx = np.argsort(w)
w = w[idx]
print(w)
v = v[:,idx]
print(v)
