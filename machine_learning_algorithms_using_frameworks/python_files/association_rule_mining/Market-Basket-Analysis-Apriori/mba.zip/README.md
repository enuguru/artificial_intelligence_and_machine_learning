# MarketBasketAnalysis_BruteForce_Apriori
Market basket analysis of retail and movie datasets.

Market basket analysis was performed using two methods:
- Brute force algorithm
- Apriori algorithm (performance enhancement using pruning technique)
