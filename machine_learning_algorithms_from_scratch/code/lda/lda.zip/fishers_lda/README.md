Fisher's LDA implementation. Run as:

python lda.py digits.csv -1

For the Boston dataset, you need to edit the file to set the convert flag and the threshold flag and reduce the num_dims parameter to 1. Then run as:

python lda.py boston.csv -1
