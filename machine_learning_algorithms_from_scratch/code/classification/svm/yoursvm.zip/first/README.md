# Support-Vector-Machine

A simple implementation of a (linear) Support Vector Machine model in python. The classifier is an object of the SVC class which was imported from sklearn.svm library.

the linear kernel type was choosen since this was a linear SVM classifier model. 
